Sample files are from: http://techslides.com/sample-files-for-development
